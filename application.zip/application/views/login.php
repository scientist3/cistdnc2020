<?php
defined('BASEPATH') OR exit('No direct script access allowed');
?>
<!DOCTYPE html>
<html>
	<head>
		<!-- Latest compiled and minified CSS -->
		<!-- <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css" integrity="sha384-BVYiiSIFeK1dGmJRAkycuHAHRg32OmUcww7on3RYdg4Va+PmSTsz/K68vbdEjh4u" crossorigin="anonymous">
 -->
		<!-- Optional theme -->
		<!-- <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap-theme.min.css" integrity="sha384-rHyoN1iRsVXV4nD0JutlnGaslCJuC7uwjduW9SVrLvRYooPp2bWYgmgJQIXwl/Sp" crossorigin="anonymous">
 -->
		<!-- Latest compiled and minified JavaScript -->
		<!-- <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js" integrity="sha384-Tc5IQib027qvyjSMfHjOMaLkfuWVxZxUPnCJA7l2mCWNIpG9mGCD8wGNIcPD7Txa" crossorigin="anonymous"></script> -->
	</head>
	<body>
		<p style="font-size:5rem;color:red;background-color: #FFC107;">
			<?php // echo $msg; ?>	
		</p>
		<h2>HTML Forms</h2>
		<?php echo "<pre>"; print_r($input); echo "</pre>"; ?>
		<!-- id username password status -->
		<?php echo form_open('login/checklogin'); ?>
			<?php echo form_label('Username'); ?>
			<?php echo form_input('username',$input['username']); ?>
			<?php echo form_label('Password'); ?>
			<?php echo form_password('password',$input['password']); ?>
			<?php echo form_submit('logincheck_btn','Login'); ?>
		</form> 
	</body>
</html>
