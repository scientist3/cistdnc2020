<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Login_model extends CI_Model {

	public function checkuser($data= []) {
		//$login_tbl_data = $this->db->select("*")->from('login_tbl')->get()->result();
		$sql = "SELECT * FROM `login_tbl` 
				WHERE 
					`username` LIKE '".$data['username']."' AND 
					`password` LIKE '".$data['username']."' AND 
					`status` = 1";

		$login_tbl_data = $this->db->query($sql)->row();
		if($login_tbl_data){
			return true;
		}else{
			return false;
		}
		print_r($login_tbl_data);
	}
}