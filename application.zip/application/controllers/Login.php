<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Login extends CI_Controller {

	public function __construct()
	{
		parent::__construct();

		$this->load->helper(array('url','form'));
		
		$this->load->model(['login_model'=>'lm']);


	}
	public function index()
	{

		redirect('login/checklogin');
	}

	public function checklogin() {

		# How to get form data from view.
		
		$data['input'] = [
			'username' 		=> $this->input->post('username'),
			'password' 		=> $this->input->post('password'),
			'logincheck_btn'=> $this->input->post('logincheck_btn'),
		];
		
		// Checking through model
		if(!empty($this->input->post('logincheck_btn'))){
			if($this->lm->checkuser($data['input'])){

			}else{

			}
		}
		
		$this->load->view('login',$data);
		

	}

	public function home() {
		$this->load->view('welcome_message');
	}
}